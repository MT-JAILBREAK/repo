Lockscreen widgets can only be applied to the user's Lockscreen.

See here for further information: https://incendo.ws/documentation/widget-api/additional-documentation/widget-layout.html
