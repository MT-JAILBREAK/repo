self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "326f20b9ce9504e4371e",
    "url": "css/app.05a92a76.css"
  },
  {
    "revision": "10b426b3e15e57fe3cb122a2712698db",
    "url": "index.html"
  },
  {
    "revision": "326f20b9ce9504e4371e",
    "url": "js/app.ff6a0340.js"
  },
  {
    "revision": "0d7265755196ca0a8fc3",
    "url": "js/chunk-vendors.95f6f2df.js"
  },
  {
    "revision": "b2a457bb622fe4a4f2bde0e44086405e",
    "url": "manifest.json"
  }
]);